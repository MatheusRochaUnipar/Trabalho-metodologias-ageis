const metodologias = {
  xp: {
    title: "⚡ eXtreme Programming (XP)",
    contexto: "Criada em 1996 por Kent Beck, a eXtreme Programming (XP) é uma das metodologias ágeis mais conhecidas por enfatizar a excelência técnica, qualidade de software e comunicação constante com o cliente. Foi projetada para ambientes de alto dinamismo, onde os requisitos mudam frequentemente, tornando-a especialmente útil em projetos de inovação e produtos digitais. O XP propõe práticas como programação em par, integração contínua, refatoração e testes automatizados, que permitem que o software evolua com segurança e rapidez. A presença ativa do cliente no processo é um de seus pilares, garantindo que as entregas atendam às reais necessidades do negócio.",

    componentes: [
      "Customer (Cliente): Define requisitos e prioridades diretamente junto à equipe.",
      "Developer (Desenvolvedor): Programa em pares e realiza refatorações constantes.",
      "Tester (Testador): Garante qualidade com testes automatizados e de aceitação.",
      "Tracker (Rastreador): Acompanha métricas de progresso e mantém a cadência das iterações.",
      "Coach (Treinador): Orienta na aplicação das práticas XP e mantém a disciplina da equipe."
    ],

    fases: [
      "Planejamento.",
      "Design Simples.",
      "Programação em Par.",
      "Testes Contínuos.",
      "Integração Contínua.",
      "Refatoração."
    ],

    vantagens: [
      "Entregas rápidas e frequentes.",
      "Feedback constante do cliente.",
      "Melhora a qualidade do código.",
      "Reduz retrabalho e erros.",
      "Estimula colaboração intensa.",
      "Alta capacidade de adaptação a mudanças."
    ],

    desvantagens: [
      "Requer cliente disponível constantemente.",
      "Demanda grande disciplina da equipe.",
      "Pode ser difícil em equipes grandes.",
      "Necessidade de testes automatizados bem estruturados.",
      "Resistência inicial de alguns desenvolvedores.",
      "Exige alta comunicação e comprometimento."
    ]
  },

  fdd: {
    title: "🎯 Feature Driven Development (FDD)",
    contexto: "O Feature Driven Development (FDD), criado em 1997 por Jeff De Luca e Peter Coad, é uma metodologia ágil orientada por funcionalidades (features). Diferente de outras abordagens, o FDD foca em dividir grandes projetos em funcionalidades pequenas, claras e de fácil acompanhamento. Seu processo é bem estruturado e organizado, tornando-o ideal para projetos de médio e grande porte, nos quais é essencial ter visibilidade do progresso e coordenação de equipes maiores. O FDD combina planejamento estratégico com ciclos curtos de entrega, mantendo a rastreabilidade das funcionalidades desenvolvidas. Essa clareza permite melhor controle de riscos e previsibilidade nos resultados.",

    componentes: [
      "Chief Architect (Arquiteto-Chefe): Define o modelo global do sistema.",
      "Class Owner (Responsável de Classe): Garante consistência e qualidade em partes específicas do código.",
      "Feature Team (Time de Funcionalidade): Implementa funcionalidades completas do início ao fim.",
      "Project Manager (Gerente de Projeto): Organiza prazos e acompanha evolução.",
      "Domain Expert (Especialista de Domínio): Traduza os requisitos de negócio em funcionalidades claras."
    ],

    fases: [
      "Desenvolvimento do modelo global.",
      "Criação da lista de funcionalidades.",
      "Planejamento por funcionalidade.",
      "Projeto por funcionalidade.",
      "Construção por funcionalidade."
    ],

    vantagens: [
      "Boa visibilidade do progresso.",
      "Organização clara por funcionalidades.",
      "Escalável para equipes grandes.",
      "Estrutura sólida e bem definida.",
      "Entregas incrementais ajudam no controle.",
      "Facilita acompanhamento de métricas."
    ],

    desvantagens: [
      "Pouca flexibilidade para mudanças frequentes.",
      "Pode gerar excesso de documentação.",
      "Menos adaptável que XP ou Kanban.",
      "Necessita papéis bem definidos.",
      "Menor envolvimento do cliente em comparação a XP.",
      "Foco maior em processos do que em pessoas."
    ]
  },

  kanban: {
    title: "📊 Kanban",
    contexto: "O Kanban tem suas origens no sistema de produção da Toyota na década de 1940 e foi adaptado para o desenvolvimento de software e gestão de projetos. Seu objetivo é organizar e otimizar o fluxo de trabalho através de um quadro visual (board), no qual tarefas são representadas por cartões. Esse quadro permite identificar gargalos, limitar o trabalho em progresso (WIP) e promover melhorias contínuas. O Kanban é altamente flexível, não impõe papéis rígidos nem ciclos fixos, sendo adequado para equipes que precisam responder rapidamente a mudanças. Sua simplicidade torna-o fácil de implementar, mas seu verdadeiro valor está no uso disciplinado e no monitoramento constante do fluxo.",

    componentes: [
      "Team Member (Membro da Equipe): Executa e move as tarefas pelo quadro Kanban.",
      "Service Request Manager (Gestor de Demandas): Prioriza o que entra no fluxo de trabalho.",
      "Flow Manager (Gestor de Fluxo): Monitora gargalos e garante fluidez no processo.",
      "Stakeholder (Interessado): Fornece demandas e acompanha transparência do fluxo.",
      "Coach (Facilitador): Promove revisões e melhorias contínuas no método Kanban."
    ],

    fases: [
      "Visualização do fluxo de trabalho.",
      "Limitação do trabalho em progresso (WIP).",
      "Gestão do fluxo e resolução de gargalos.",
      "Revisões e melhorias contínuas."
    ],

    vantagens: [
      "Simples de implementar.",
      "Flexível para diferentes contextos.",
      "Melhora a transparência do processo.",
      "Reduz gargalos.",
      "Estimula melhoria contínua.",
      "Ajuda no balanceamento da carga de trabalho."
    ],

    desvantagens: [
      "Não define prazos rígidos.",
      "Pode ser confuso sem disciplina.",
      "Exige monitoramento constante.",
      "Pouca padronização entre equipes.",
      "Difícil de usar em projetos críticos com prazos fixos.",
      "Foco maior no fluxo do que na entrega de valor."
    ]
  },

  crystal: {
    title: "💎 Crystal",
    contexto: "A família de metodologias Crystal foi criada por Alistair Cockburn e se diferencia por oferecer variações (como Crystal Clear, Crystal Orange, etc.) adaptáveis ao tamanho da equipe e à criticidade do projeto. Ao contrário de metodologias rígidas, o Crystal prioriza a comunicação direta, a transparência e a adaptação ao contexto. Seu foco é manter a equipe produtiva com o mínimo de burocracia possível, favorecendo entregas incrementais e aprendizado constante. Quanto maior e mais crítico o projeto, mais robusta deve ser a versão do Crystal utilizada. É uma abordagem que valoriza pessoas acima de processos, mas exige maturidade da equipe para funcionar bem.",

    componentes: [
      "Customer (Cliente): Define objetivos claros e fornece feedback.",
      "Developer (Desenvolvedor): Trabalha de forma colaborativa e entrega incrementos frequentes.",
      "Coordinator (Coordenador): Facilita a comunicação e remove impedimentos.",
      "Tester (Testador): Realiza testes frequentes para garantir qualidade.",
      "Mentor (Mentor): Apoia a equipe na adaptação das práticas conforme o contexto."
    ],

    fases: [
      "Comunicação contínua.",
      "Entregas incrementais.",
      "Testes e revisões frequentes.",
      "Adaptação do processo conforme necessidade."
    ],

    vantagens: [
      "Alta flexibilidade.",
      "Adapta-se a diferentes contextos.",
      "Valoriza pessoas e interações.",
      "Entregas rápidas e frequentes.",
      "Menos burocracia.",
      "Estimula aprendizado contínuo."
    ],

    desvantagens: [
      "Pouco estruturado para grandes equipes.",
      "Pode gerar inconsistência entre projetos.",
      "Difícil padronização em grandes empresas.",
      "Requer equipe madura e engajada.",
      "Documentação mínima pode causar falhas.",
      "Depende muito da comunicação interpessoal."
    ]
  },

  msf: {
    title: "🛠️ Microsoft Solutions Framework (MSF)",
    contexto: "O Microsoft Solutions Framework (MSF) foi desenvolvido pela Microsoft como um conjunto abrangente de princípios, modelos e boas práticas para gerenciar projetos complexos de software. Diferente das metodologias ágeis puras, o MSF busca equilíbrio entre flexibilidade e estrutura, fornecendo papéis bem definidos e um processo claro de governança. É especialmente voltado para grandes organizações que precisam de previsibilidade, documentação robusta e integração entre diversas equipes e áreas de negócio. Apesar de ser mais burocrático, oferece maior segurança e padronização para projetos corporativos de larga escala.",

    componentes: [
      "Product Management (Gestão de Produto): Define visão e necessidades do cliente.",
      "Program Management (Gestão de Programa): Planeja entregas e coordena equipes.",
      "Development (Desenvolvimento): Implementa soluções técnicas.",
      "Testing (Teste): Valida qualidade e conformidade.",
      "User Experience (Experiência do Usuário): Garante usabilidade e aderência ao produto.",
      "Release Management (Gestão de Entrega): Coordena implantação e estabilização do sistema."
    ],

    fases: [
      "Envisioning (visão e objetivos).",
      "Planning (planejamento detalhado).",
      "Developing (implementação).",
      "Stabilizing (testes e ajustes).",
      "Deploying (entrega e manutenção inicial)."
    ],

    vantagens: [
      "Estrutura robusta e detalhada.",
      "Integra bem processos e equipes.",
      "Adequado para projetos corporativos.",
      "Boa gestão de riscos.",
      "Suporte amplo da Microsoft.",
      "Facilita governança e controle."
    ],

    desvantagens: [
      "Menos ágil e flexível.",
      "Mais burocrático.",
      "Exige maior documentação.",
      "Pode ser demorado em adaptações.",
      "Requer treinamento especializado.",
      "Menos indicado para projetos pequenos."
    ]
  }
};

function showContent(metodologia) {
  const data = metodologias[metodologia];
  if (!data) return;

  document.getElementById("metodologia_titulo").innerText = data.title;
  document.getElementById("contexto_texto").innerText = data.contexto;

  const componentesList = document.getElementById("componentes_texto");
  componentesList.innerHTML = "";
  if (Array.isArray(data.componentes)) {
    data.componentes.forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      componentesList.appendChild(li);
    });
  } else {
    const li = document.createElement("li");
    li.textContent = data.componentes;
    componentesList.appendChild(li);
  }

  const fasesList = document.getElementById("fases_texto");
  fasesList.innerHTML = "";
  if (Array.isArray(data.fases)) {
    data.fases.forEach((item, index) => {
      const li = document.createElement("li");
      li.innerHTML = `<span class="num">${index + 1}</span> ${item}`;
      fasesList.appendChild(li);
    });
  } else {
    const li = document.createElement("li");
    li.innerHTML = `<span class="num">1</span> ${data.fases}`;
    fasesList.appendChild(li);
  }

  const vantagensList = document.getElementById("vantagens_texto");
  vantagensList.innerHTML = "";
  if (Array.isArray(data.vantagens)) {
    data.vantagens.forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      vantagensList.appendChild(li);
    });
  } else {
    const li = document.createElement("li");
    li.textContent = data.vantagens;
    vantagensList.appendChild(li);
  }

  const desvantagensList = document.getElementById("desvantagens_texto");
  desvantagensList.innerHTML = "";
  if (Array.isArray(data.desvantagens)) {
    data.desvantagens.forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      desvantagensList.appendChild(li);
    });
  } else if (data.desvantagens) {
    const li = document.createElement("li");
    li.textContent = data.desvantagens;
    desvantagensList.appendChild(li);
  }

  document.getElementById("conteudo").style.display = "block";

  const guias = document.querySelectorAll(".card_metodologias_guias");
  const conteudos = document.querySelectorAll(".conteudo_guia");

  guias.forEach(tab => tab.classList.remove("ativo-guia"));
  conteudos.forEach(content => content.classList.remove("ativo-conteudo"));

  document.querySelector(".card_metodologias_guias").classList.add("ativo-guia");
  document.getElementById("context").classList.add("ativo-conteudo");
}

function switchTab(event, guiaId) {
  const guias = document.querySelectorAll(".card_metodologias_guias");
  const conteudos = document.querySelectorAll(".conteudo_guia");

  guias.forEach(tab => tab.classList.remove("ativo-guia"));
  conteudos.forEach(content => content.classList.remove("ativo-conteudo"));

  event.currentTarget.classList.add("ativo-guia");
  document.getElementById(guiaId).classList.add("ativo-conteudo");
}

function hideContent() {
  document.getElementById("conteudo").style.display = "none";
}

function scrollToCard(cardId) {
  const card = document.getElementById(cardId);
  if (card) {
    card.scrollIntoView({ behavior: "smooth", block: "start" });

    setTimeout(() => {
      showContent(cardId);
    }, 600);
  }
}

function scrollToMetodologias() {
  const section = document.querySelector(".metodologias");
  if (section) {
    section.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}
